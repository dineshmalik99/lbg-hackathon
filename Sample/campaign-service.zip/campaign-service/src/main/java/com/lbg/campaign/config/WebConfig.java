package com.lbg.campaign.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // or specify a more specific path
                .allowedOrigins("*") // allows only requests from this origin
                .allowedMethods("GET", "POST", "PUT", "DELETE"); // specify the allowed methods
    }
}

