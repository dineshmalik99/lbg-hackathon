package com.lbg.consumer.service;

import com.lbg.consumer.config.TwilioConfig;
import com.lbg.consumer.model.CommunicationMessage;
import com.twilio.type.PhoneNumber;
import org.springframework.stereotype.Service;import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

@Service
public class SMSService {
    private final TwilioConfig twilioConfig;

    public SMSService(TwilioConfig twilioConfig) {
        this.twilioConfig = twilioConfig;
    }
    public void sendSMS(CommunicationMessage msg) {
        Message message = Message.creator(
                new PhoneNumber(twilioConfig.getPhoneNumber()),
                new PhoneNumber("+13412301598"),
                msg.getContent()
        ).create();

        System.out.println("SMS sent: " + message.getSid());

    }
}
