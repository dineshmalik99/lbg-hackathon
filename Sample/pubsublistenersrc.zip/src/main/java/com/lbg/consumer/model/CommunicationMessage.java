package com.lbg.consumer.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommunicationMessage {
    private String type; // e.g., "email", "sms", "push"
    private String recipient;
    private String content;

}
