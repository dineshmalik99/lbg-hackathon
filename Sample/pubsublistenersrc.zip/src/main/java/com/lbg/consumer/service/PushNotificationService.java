package com.lbg.consumer.service;

import com.lbg.consumer.model.CommunicationMessage;
import org.springframework.stereotype.Service;

@Service
public class PushNotificationService {
    public void sendPush(CommunicationMessage msg) {
        // Logic to send push notification
        System.out.println("Sending push notifications to " + msg.getRecipient() + " with content: " + msg.getContent());
    }
}
