package com.lbg.consumer.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.consumer.model.CommunicationMessage;
import com.lbg.consumer.service.EmailService;
import com.lbg.consumer.service.PushNotificationService;
import com.lbg.consumer.service.SMSService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

@RestController
@RequestMapping("/pubsub")
public class PubSubController {

        private final EmailService emailService;
        private final SMSService smsService;
        private final PushNotificationService pushService;

    @Autowired
    public PubSubController(EmailService emailService, SMSService smsService, PushNotificationService pushService) {
        this.emailService = emailService;
        this.smsService = smsService;
        this.pushService = pushService;
    }
    @PostMapping("/message")
    public ResponseEntity<String> receiveMessage(@RequestBody Map<String, Object> payload) {
        Map<String, Object> message = (Map<String, Object>) payload.get("message");
        String data = new String(Base64.getDecoder().decode((String) message.get("data")), StandardCharsets.UTF_8);

        ObjectMapper mapper = new ObjectMapper();
        try {
            CommunicationMessage comm = mapper.readValue(data, CommunicationMessage.class);
            switch (comm.getType().toLowerCase()) {
                case "email" -> emailService.sendEmail(comm);
                case "sms" -> smsService.sendSMS(comm);
                case "push" -> pushService.sendPush(comm);
                default -> throw new IllegalArgumentException("Unsupported message type: " + comm.getType());
            }
            return ResponseEntity.ok("Message processed");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error processing message: " + e.getMessage());
        }
    }

}
