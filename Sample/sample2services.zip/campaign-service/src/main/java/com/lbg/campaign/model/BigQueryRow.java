package com.lbg.campaign.model;

import java.util.HashMap;
import java.util.Map;

public class BigQueryRow {
    private final Map<String, Object> fields = new HashMap<>();

    public void addField(String name, Object value) {
        fields.put(name, value);
    }

    public Map<String, Object> getFields() {
        return fields;
    }
}

