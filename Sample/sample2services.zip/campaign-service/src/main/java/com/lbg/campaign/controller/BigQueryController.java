package com.lbg.campaign.controller;

import com.lbg.campaign.model.BigQueryRow;
import com.lbg.campaign.service.BigQueryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bigquery")
public class BigQueryController {
    private final BigQueryService bigQueryService;

    public BigQueryController(BigQueryService bigQueryService) {
        this.bigQueryService = bigQueryService;
    }

    @GetMapping("/query")
    public ResponseEntity<String> runQuery(@RequestParam String q) {
        String result = bigQueryService.runQuery(q);
        return ResponseEntity.ok(result);
    }
    @GetMapping("/fetch")
    public ResponseEntity<String> fetchData(
            @RequestParam String projectId,
            @RequestParam String dataset,
            @RequestParam String table
    ) {
        String data = bigQueryService.fetchData(projectId, dataset, table);
        return ResponseEntity.ok(data);
    }
    @GetMapping("/fetchStructure")
    public ResponseEntity<List<BigQueryRow>> fetchDataS(
            @RequestParam String projectId,
            @RequestParam String dataset,
            @RequestParam String table
    ) {
        List<BigQueryRow> data = bigQueryService.fetchStructuredData(projectId, dataset, table);
        return ResponseEntity.ok(data);
    }
}
