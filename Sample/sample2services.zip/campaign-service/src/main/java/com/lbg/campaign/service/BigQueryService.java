package com.lbg.campaign.service;

import com.google.cloud.bigquery.*;
import com.lbg.campaign.model.BigQueryRow;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class BigQueryService {
    private final BigQuery bigQuery;

    public BigQueryService(BigQuery bigQuery) {
        this.bigQuery = bigQuery;
    }

    public String runQuery(String queryString) {
        QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(queryString).build();
        try {
            TableResult result = bigQuery.query(queryConfig);
            StringBuilder output = new StringBuilder();
            for (FieldValueList row : result.iterateAll()) {
                output.append(row.toString()).append("\n");
            }
            return output.toString();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return "Query interrupted: " + e.getMessage();
        }
    }
    public String fetchData(String projectId, String dataset, String table) {
        String query = String.format("SELECT * FROM `%s.%s.%s` LIMIT 10", projectId, dataset, table);
        QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).build();
        StringBuilder resultBuilder = new StringBuilder();

        try {
            TableResult result = bigQuery.query(queryConfig);
            for (FieldValueList row : result.iterateAll()) {
                for (Field field : Objects.requireNonNull(result.getSchema()).getFields()) {
                    resultBuilder.append(field.getName())
                            .append(": ")
                            .append(row.get(field.getName()).getValue())
                            .append(", ");
                }
                resultBuilder.append("\n");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return "Query interrupted: " + e.getMessage();
        }

        return resultBuilder.toString();
    }
    public List<BigQueryRow> fetchStructuredData(String projectId, String dataset, String table) {
        String query = String.format("SELECT * FROM `%s.%s.%s` LIMIT 10", projectId, dataset, table);
        QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).build();
        List<BigQueryRow> rows = new ArrayList<>();

        try {
            TableResult result = bigQuery.query(queryConfig);
            for (FieldValueList row : result.iterateAll()) {
                BigQueryRow bqRow = new BigQueryRow();
                for (Field field : result.getSchema().getFields()) {
                    bqRow.addField(field.getName(), row.get(field.getName()).getValue());
                }
                rows.add(bqRow);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Query interrupted", e);
        }

        return rows;
    }
}

