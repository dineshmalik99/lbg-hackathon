package com.lbg.consumer.service;

import com.lbg.consumer.model.CommunicationMessage;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }
    public void sendEmail(CommunicationMessage communicationMessage) {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(communicationMessage.getRecipient());
            System.out.println("to::"+communicationMessage.getRecipient());
            message.setSubject("Subject");
            message.setText(communicationMessage.getContent());
            System.out.println("content::"+communicationMessage.getContent());
            message.setFrom("maddineni.mouni@gmail.com");
            mailSender.send(message);

    }
}
