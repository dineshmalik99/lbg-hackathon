package com.lbg.consumer.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

import java.io.FileInputStream;
import java.io.IOException;


public class GCSConfig {
    @Profile("gcp")
    @Bean
    public static Storage createStorage() throws IOException {
        GoogleCredentials credentials = GoogleCredentials.fromStream(
                new FileInputStream("C:\\Users\\91917\\IdeaProjects\\consumer\\communication-service\\src\\main\\resources\\key.json")
        );
        return StorageOptions.newBuilder()
                .setCredentials(credentials)
                .build()
                .getService();
    }
}
